<?php
return [
	"title_index" => "Temas",
    "general" => "Generales",
	"datatables" => "Datatables y botones",
    "header" => "Encabezado",
    "logo" => "Logo",
    "background_color" => "Color de fondo",
    "font_color" => "Color de fuente",
	"font_hover_color" => "Color de hover",
    "font" => "Fuente",

    "menu" => "Menú",
    "position" => "Posición",
    "left" => "Izquierda",
    "top" => "Arriba",
    "show_menu_icons" => "Mostrar iconos del menú",
    
    "body" => "Cuerpo",
    "footer" => "Pie de página",

	"data[general_header_font_id]" => "Fuente",
	"data[general_menu_font_id]" => "Fuente",
	"data[general_body_font_id]" => "Fuente",
	"data[general_footer_font_id]" => "Fuente",


];