<?php
return [
	//Titles
	"title_index" => "universos",
	"title_add" => "Agregar universo",
	"title_show" => "Ver universo",
	"title_edit" => "Modificar universo",
	"title_delete" => "Eliminar universo",

	//Fields
	"id" => "id",
	"created_at" => "Fecha creado",
	"updated_at" => "Fecha modificado",

	//Action messages
	"confirm_delete" => "Se borrará universo de la base de datos. ¿Desea continuar?",
	"Successfully created" => "universo creado correctamente",
	"Successfully updated" => "universo modificado correctamente",
	"Successfully deleted" => "universo eliminado correctamente",
	"delete_error_message" => "Error al intentar eliminar universo de la base de datos",
	"delete_error_message_constraint" => "No se puede eliminar universo, hay tablas que dependen de este",
];