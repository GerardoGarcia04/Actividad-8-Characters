<?php
return [
	//Titles
	"title_index" => "Personajes",
	"title_add" => "Agregar personaje",
	"title_show" => "Ver personaje",
	"title_edit" => "Modificar personaje",
	"title_delete" => "Eliminar personaje",

	//Fields
	"id" => "id",
	"nombre" => "Nombre de Superhéroe",
	"nombre_real" => "Nombre real",
	"foto" => "Foto",
	"genero" => "Género",
	"información_adicional" => "Información Adicional",
	"id_universe" => "Id de Universo",
	"created_at" => "Fecha creado",
	"updated_at" => "Fecha modificado",

	//Action messages
	"confirm_delete" => "Se borrará personaje de la base de datos. ¿Desea continuar?",
	"Successfully created" => "personaje creado correctamente",
	"Successfully updated" => "personaje modificado correctamente",
	"Successfully deleted" => "personaje eliminado correctamente",
	"delete_error_message" => "Error al intentar eliminar personaje de la base de datos",
	"delete_error_message_constraint" => "No se puede eliminar personaje, hay tablas que dependen de este",
];