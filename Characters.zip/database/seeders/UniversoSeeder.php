<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use App\Models\Universo;

class UniversoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Universo::create([
            "id" =>'1',
			"universo" => 'U1',
			"compañia" => 'DC',
			"edad" => 'silvery',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

        Universo::create([
            "id" =>'2',
			"universo" => 'U2',
			"compañia" => 'DC',
			"edad" => 'golden',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

        Universo::create([
            "id" =>'3',
			"universo" => 'U3',
			"compañia" => 'DC',
			"edad" => 'modern',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

        Universo::create([
            "id" =>'4',
			"universo" => 'U4',
			"compañia" => 'Marvel',
			"edad" => 'silvery',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

        Universo::create([
            "id" =>'5',
			"universo" => 'U5',
			"compañia" => 'Marvel',
			"edad" => 'modern',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);
    }
}
