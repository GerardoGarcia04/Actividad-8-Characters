<?php

namespace Database\Seeders;


use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use App\Models\Personaje;

class PersonajeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Personaje::create([
            "id" =>'1',
			"nombre" => 'Spider-Man',
			"nombre_real" => 'Peter Benjamin Parker',
			"foto" => 'https://en.wikipedia.org/wiki/Spider-Man',
			"genero" => 'Male',
			"información_adicional" => 'https://en.wikipedia.org/wiki/Spider-Man',
            "id_universe" => '4',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

        Personaje::create([
            "id" =>'2',
			"nombre" => 'Hulk',
			"nombre_real" => 'Robert Bruce Banner',
			"foto" => 'https://en.wikipedia.org/wiki/Hulk',
			"genero" => 'Male',
			"información_adicional" => 'https://en.wikipedia.org/wiki/Hulk',
            "id_universe" => '4',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

        Personaje::create([
            "id" =>'3',
			"nombre" => 'Captain America',
			"nombre_real" => 'Steven Rogers',
			"foto" => 'https://en.wikipedia.org/wiki/Captain_America',
			"genero" => 'Male',
			"información_adicional" => 'https://en.wikipedia.org/wiki/Captain_America',
            "id_universe" => '4',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

        Personaje::create([
            "id" =>'4',
			"nombre" => 'Superman',
			"nombre_real" => 'Clark Kent',
			"foto" => 'https://en.wikipedia.org/wiki/Superman',
			"genero" => 'Male',
			"información_adicional" => 'https://en.wikipedia.org/wiki/Superman',
            "id_universe" => '2',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

        Personaje::create([
            "id" =>'5',
			"nombre" => 'Batman',
			"nombre_real" => 'Bruce Wayne',
			"foto" => 'https://en.wikipedia.org/wiki/Batman',
			"genero" => 'Male',
			"información_adicional" => 'https://en.wikipedia.org/wiki/Batman',
            "id_universe" => '1',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

        Personaje::create([
            "id" =>'6',
			"nombre" => 'Scarlet Spider',
			"nombre_real" => 'Ben Reilly',
			"foto" => 'https://en.wikipedia.org/wiki/Scarlet_Spider',
			"genero" => 'Male',
			"información_adicional" => 'https://en.wikipedia.org/wiki/Scarlet_Spider',
            "id_universe" => '5',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

        Personaje::create([
            "id" =>'7',
			"nombre" => 'Wonder Woman',
			"nombre_real" => 'Diana Prince',
			"foto" => 'https://en.wikipedia.org/wiki/Wonder_Woman',
			"genero" => 'Female',
			"información_adicional" => 'https://en.wikipedia.org/wiki/Wonder_Woman',
            "id_universe" => '1',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

        Personaje::create([
            "id" =>'8',
			"nombre" => 'Doomsday',
			"nombre_real" => 'Not Applicable',
			"foto" => 'https://en.wikipedia.org/wiki/Doomsday',
			"genero" => 'Male',
			"información_adicional" => 'https://en.wikipedia.org/wiki/Doomsday',
            "id_universe" => '3',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

        Personaje::create([
            "id" =>'9',
			"nombre" => 'Scarlet Witch',
			"nombre_real" => 'Wanda Maximoff',
			"foto" => 'https://en.wikipedia.org/wiki/Scarlet_Witch',
			"genero" => 'Female',
			"información_adicional" => 'https://en.wikipedia.org/wiki/Scarlet_Witch',
            "id_universe" => '5',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

        Personaje::create([
            "id" =>'10',
			"nombre" => 'Nigth Wing',
			"nombre_real" => 'Dick Grayson',
			"foto" => 'https://es.wikipedia.org/wiki/Nightwing_(DC_Comics)',
			"genero" => 'Male',
			"información_adicional" => 'https://es.wikipedia.org/wiki/Nightwing_(DC_Comics)',
            "id_universe" => '3',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);
    }
}
