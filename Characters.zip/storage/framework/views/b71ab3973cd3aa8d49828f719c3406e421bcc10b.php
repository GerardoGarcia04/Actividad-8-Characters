<?php if(session()->has('message')): ?>
	<div class="alert alert-info dismissible">
		<button type="button" class="btn btn-default" data-bs-dismiss="alert" aria-label="Close">
			<i class="fa-solid fa-xmark"></i>
		</button>
		<?php echo session()->get('message'); ?>

	</div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
	<div class="alert alert-danger dismissible">
		<button type="button" class="btn btn-default" data-bs-dismiss="alert" aria-label="Close">
			<i class="fa-solid fa-xmark"></i>
		</button>
		<?php echo session()->get('error'); ?>

	</div>
<?php endif; ?>
<?php if($errors->any()): ?>
	<div class="alert alert-danger dismissible">
		<button type="button" class="btn btn-default" data-bs-dismiss="alert" aria-label="Close">
			<i class="fa-solid fa-xmark"></i>
		</button>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo $error; ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\characters\resources\views/crud-maker/components/session-alerts.blade.php ENDPATH**/ ?>