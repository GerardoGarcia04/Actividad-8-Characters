

<?php $__env->startSection('datatable'); ?>
	<?php echo e($dataTable->table(["width" => "100%"])); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('crud-maker.layouts.index', [
	'title' => __('universos.title_index'), 
	'entity' => 'universos', 
	'form' => 'universo',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\characters\resources\views/universos/index.blade.php ENDPATH**/ ?>