<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "nombre",
		"id" => "nombre",
		"class" => "form-control",
		"entity" => "personajes",
		"type" => "text",
		"defaultValue" => old("nombre") ?? ($personajes->nombre ?? ""),
		"required" => "true",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "nombre_real",
		"id" => "nombre_real",
		"class" => "form-control",
		"entity" => "personajes",
		"type" => "text",
		"defaultValue" => old("nombre_real") ?? ($personajes->nombre_real ?? ""),
		"required" => "true",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "foto",
		"id" => "foto",
		"class" => "form-control",
		"entity" => "personajes",
		"type" => "text",
		"defaultValue" => old("foto") ?? ($personajes->foto ?? ""),
		"required" => "true",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "genero",
		"id" => "genero",
		"class" => "form-control",
		"entity" => "personajes",
		"type" => "text",
		"defaultValue" => old("genero") ?? ($personajes->genero ?? ""),
		"required" => "true",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "información_adicional",
		"id" => "información_adicional",
		"class" => "form-control",
		"entity" => "personajes",
		"type" => "text",
		"defaultValue" => old("información_adicional") ?? ($personajes->información_adicional ?? ""),
		"required" => "true",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "id_universe",
		"id" => "id_universe",
		"class" => "form-control",
		"entity" => "personajes",
		"type" => "text",
		"defaultValue" => old("id_universe") ?? ($personajes->id_universe ?? ""),
		"required" => "true",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\characters\resources\views/personajes/fields.blade.php ENDPATH**/ ?>