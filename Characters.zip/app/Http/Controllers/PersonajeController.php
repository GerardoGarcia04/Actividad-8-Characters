<?php

namespace App\Http\Controllers;

use App\Models\Personaje;

use App\Http\Requests\PersonajeRequest;
use App\DataTables\PersonajeDataTable;
use Illuminate\Http\Request;

class PersonajeController extends Controller
{
	public function index()
	{
		//Consultar permiso para botón de agregar
		$allowAdd = auth()->user()->hasPermissions("personajes.create");
		$allowEdit = auth()->user()->hasPermissions("personajes.edit");
		return (new PersonajeDataTable())->render('personajes.index', compact('allowAdd', 'allowEdit'));
	}
	public function create()
	{
		return view('personajes.create');
	}
	public function store(PersonajeRequest $request)
	{
		$status = true;
		$personaje = null;
		$params = array_merge($request->all(), [
			'created_by' => auth()->id(),
			'updated_by' => auth()->id(),
			'created_at' => date("Y-m-d H:i:s"),
			'updated_at' => date("Y-m-d H:i:s")
		]);
		try {
			$personaje = Personaje::create($params);
			$message = __('personajes.Successfully created');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'personajes');
		}
		return $this->getResponse($status, $message, $personaje);
	}
	public function show(Personaje $personaje)
	{
		return view('personajes.show', compact('personaje'));
	}
	public function edit(Personaje $personaje)
	{
		return view('personajes.edit', compact('personaje'));
	}
	public function update(PersonajeRequest $request, Personaje $personaje)
	{
		$status = true;
		$params = array_merge($request->all(), [
			'updated_by' => auth()->id(),
			'updated_at' => date("Y-m-d H:i:s")
		]);
		try {
			$personaje->update($params);
			$message = __('personajes.Successfully updated');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'personajes');
		}
		return $this->getResponse($status, $message, $personaje);
	}
	public function destroy(Personaje $personaje)
	{
		$status = true;
		try {
			$personaje->delete();
			$message = __('personajes.Successfully deleted');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'personajes');
		}
		return $this->getResponse($status, $message);
	}
	public function getQuickModalContent(Personaje $personaje = null)
	{
		$params = request("params");
		return response()->json(view('crud-maker.components.modal-quickadd', compact('params', 'personaje'))->render());
	}
}
