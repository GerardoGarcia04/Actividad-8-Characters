<?php

namespace App\Http\Controllers;

use App\Models\Universo;

use App\Http\Requests\UniversoRequest;
use App\DataTables\UniversoDataTable;
use Illuminate\Http\Request;

class UniversoController extends Controller
{
	public function index()
	{
		//Consultar permiso para botón de agregar
		$allowAdd = auth()->user()->hasPermissions("universos.create");
		$allowEdit = auth()->user()->hasPermissions("universos.edit");
		return (new UniversoDataTable())->render('universos.index', compact('allowAdd', 'allowEdit'));
	}
	public function create()
	{
		return view('universos.create');
	}
	public function store(UniversoRequest $request)
	{
		$status = true;
		$universo = null;
		$params = array_merge($request->all(), [
			'created_by' => auth()->id(),
			'updated_by' => auth()->id(),
			'created_at' => date("Y-m-d H:i:s"),
			'updated_at' => date("Y-m-d H:i:s")
		]);
		try {
			$universo = Universo::create($params);
			$message = __('universos.Successfully created');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'universos');
		}
		return $this->getResponse($status, $message, $universo);
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  \App\Universo  $universo
	 * @return \Illuminate\Http\Response
	 */
	public function show(Universo $universo)
	{
		return view('universos.show', compact('universo'));
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  \App\Universo  $universo
	 * @return \Illuminate\Http\Response
	 */
	public function edit(Universo $universo)
	{
		return view('universos.edit', compact('universo'));
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \App\Universo  $universo
	 * @return \Illuminate\Http\Response
	 */
	public function update(UniversoRequest $request, Universo $universo)
	{
		$status = true;
		$params = array_merge($request->all(), [
			'updated_by' => auth()->id(),
			'updated_at' => date("Y-m-d H:i:s")
		]);
		try {
			$universo->update($params);
			$message = __('universos.Successfully updated');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'universos');
		}
		return $this->getResponse($status, $message, $universo);
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  \App\Universo  $universo
	 * @return \Illuminate\Http\Response
	 */
	public function destroy(Universo $universo)
	{
		$status = true;
		try {
			$universo->delete();
			$message = __('universos.Successfully deleted');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'universos');
		}
		return $this->getResponse($status, $message);
	}

	public function getQuickModalContent(Universo $universo = null)
	{
		$params = request("params");
		return response()->json(view('crud-maker.components.modal-quickadd', compact('params', 'universo'))->render());
	}
}
