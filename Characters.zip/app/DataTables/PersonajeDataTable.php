<?php

namespace App\DataTables;

use App\Models\Personaje;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Html\Editor\Editor;
use Yajra\DataTables\Html\Editor\Fields;
use Yajra\DataTables\Services\DataTable;

class PersonajeDataTable extends BlankDataTable
{
	public function __construct()
	{
		$this->routeResource = 'personajes';
	}
	/**
	 * Get query source of dataTable.
	 *
	 * @param \App\Selling $model
	 * @return \Illuminate\Database\Eloquent\Builder
	 */
	public function query(Personaje $model)
	{
		return $model
		->newQuery();
	}

	/**
	 * Get columns.
	 *
	 * @return array
	 */
	protected function getColumns()
	{
		$pColumns = parent::getColumns();
		$columns = [
			['data' => 'id', 'visible' => false, 'title' => __('personajes.id')],
			['data' => 'nombre', 'title' => __('personajes.nombre')],
			['data' => 'nombre_real', 'title' => __('personajes.nombre_real')],
			['data' => 'foto', 'title' => __('personajes.foto')],
			['data' => 'genero', 'title' => __('personajes.genero')],
			['data' => 'información_adicional', 'title' => __('personajes.información_adicional')],
			['data' => 'id_universe', 'title' => __('personajes.id_universe')],
			['data' => 'created_at', 'visible' => false, 'title' => __('personajes.created_at')],
			['data' => 'updated_at', 'visible' => false, 'title' => __('personajes.updated_at')],
		];
		return array_merge($columns, $pColumns);
	}
}
