<?php

namespace App\DataTables;

use App\Models\Universo;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Html\Editor\Editor;
use Yajra\DataTables\Html\Editor\Fields;
use Yajra\DataTables\Services\DataTable;

class UniversoDataTable extends BlankDataTable
{
	public function __construct()
	{
		$this->routeResource = 'universos';
	}
	/**
	 * Get query source of dataTable.
	 *
	 * @param \App\Selling $model
	 * @return \Illuminate\Database\Eloquent\Builder
	 */
	public function query(Universo $model)
	{
		return $model
		->newQuery();
	}

	/**
	 * Get columns.
	 *
	 * @return array
	 */
	protected function getColumns()
	{
		$pColumns = parent::getColumns();
		$columns = [
			['data' => 'id', 'visible' => false, 'title' => __('universos.id')],
			['data' => 'universo', 'title' => __('universos.universo')],
			['data' => 'compañia', 'title' => __('universos.compañia')],
			['data' => 'edad', 'title' => __('universos.edad')],
			['data' => 'created_at', 'visible' => false, 'title' => __('universos.created_at')],
			['data' => 'updated_at', 'visible' => false, 'title' => __('universos.updated_at')],
		];
		return array_merge($columns, $pColumns);
	}
}
