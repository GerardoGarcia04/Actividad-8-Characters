<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Personaje extends Model
{
	use HasFactory;
	
	protected $table = 'personajes';
	protected $fillable = ['nombre', 'nombre_real', 'foto', 'genero', 'información_adicional', 'id_universe', 'created_at', 'updated_at'];

	
}