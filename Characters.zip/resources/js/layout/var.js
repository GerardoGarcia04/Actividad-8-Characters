//En este apartado declaramos el tamaño de lo que será la pantalla de móvil.
window.mobileWidth = 578;
window.isMobile = $(window).width() < mobileWidth ? true : false;