@extends('crud-maker.layouts.index', [
	'title' => __('personajes.title_index'), 
	'entity' => 'personajes', 
	'form' => 'personajes',
])

@section('datatable')
	{{ $dataTable->table(["width" => "100%"]) }}
@endsection