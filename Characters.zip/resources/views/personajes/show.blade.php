@extends('layouts.app', [
	'title' => __('personajes.title_show'), 
])

@section('content')
<div class="report-container p-3">
	<div class="row">
		<div class="col-sm-12 col-md-6 offset-md-3">
			<br>
			<div class="card card-info">
				<div class="card-header">
					<div class="row">
						<div class="col-sm-12 col-md-6 card-title">@lang('personajes.title_show')</div>
						<div class="col-sm-12 col-md-6 text-right">
							<a href="{{ route('personajes.index') }}">
								<i class="fas fa-long-arrow-alt-left"></i>
							</a>
						</div>
					</div>
				</div>
				<div class="card-body">
					
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('personajes.id')</div>
						<div class="col-sm-6">{{ $personajes->id }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('personajes.nombre')</div>
						<div class="col-sm-6">{{ $personajes->nombre }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('personajes.nombre_real')</div>
						<div class="col-sm-6">{{ $personajes->nombre_real }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('personajes.foto')</div>
						<div class="col-sm-6">{{ $personajes->foto }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('personajes.genero')</div>
						<div class="col-sm-6">{{ $personajes->genero }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('personajes.información_adicional')</div>
						<div class="col-sm-6">{{ $personajes->información_adicional }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('personajes.id_universe')</div>
						<div class="col-sm-6">{{ $personajes->id_universe }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('personajes.created_at')</div>
						<div class="col-sm-6">{{ $personajes->created_at }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('personajes.updated_at')</div>
						<div class="col-sm-6">{{ $personajes->updated_at }}</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection