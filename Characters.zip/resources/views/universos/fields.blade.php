@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "universo",
		"id" => "universo",
		"class" => "form-control",
		"entity" => "universos",
		"type" => "text",
		"defaultValue" => old("universo") ?? ($universos->universo ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "compañia",
		"id" => "compañia",
		"class" => "form-control",
		"entity" => "universos",
		"type" => "text",
		"defaultValue" => old("compañia") ?? ($universos->compañia ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "edad",
		"id" => "edad",
		"class" => "form-control",
		"entity" => "universos",
		"type" => "text",
		"defaultValue" => old("edad") ?? ($universos->edad ?? ""),
		"required" => "true",
	]
]])
