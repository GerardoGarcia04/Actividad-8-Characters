@extends('crud-maker.layouts.index', [
	'title' => __('universos.title_index'), 
	'entity' => 'universos', 
	'form' => 'universos',
])

@section('datatable')
	{{ $dataTable->table(["width" => "100%"]) }}
@endsection